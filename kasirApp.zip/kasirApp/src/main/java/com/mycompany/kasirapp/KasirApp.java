/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.kasirapp;

import com.mycompany.kasirapp.component.frame;
import com.mycompany.kasirapp.view.index;
import com.mycompany.kasirapp.dbConnection.dbConfig;
/**
 *
 * @author Acer SPIN
 */
public class KasirApp extends index{

    public static void main(String[] args) {
//        index jFrame = new index();
//        jFrame.setVisible(true);
//        jFrame.pack();
//        jFrame.setSize(360, 800);
    index jFrame = new index();

    }
}
