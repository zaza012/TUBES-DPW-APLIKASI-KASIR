/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.kasirapp.authentication;

import com.mycompany.kasirapp.model.Cashier;
import com.mycompany.kasirapp.model.Supermarket;

/**
 *
 * @author Acer SPIN
 */
public class Auth {
    public static Supermarket supermarket;
    public static Cashier cashier;
}
